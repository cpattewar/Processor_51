ALU_test.vhd is test bench file for testing ALU.
Decoder_test.vhd is test bench file for testing Decoder.
