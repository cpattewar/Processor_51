1. Install Python 2.7(please be careful of the version because the commands change along with the version in python) 
	
a. Add 'Python' as an environment variable
	
b. Add to 'Path' your location of python installation
	
c. type 'python' in your command prompt to check if it was added correctly 


2. Write your assembly language instructions in crude_code.txt in the following format
	
say you wanna write add $1, $2, $3 then write it like add, 1,2,3. Give a 'comma' after your mnemonic and no need to add any $ sign


3. Run the code something.py (sorry for the name: apparently the name 'assembler' was creating some problems)
	python something.py


4. You will find your hex instructions in hex_code.txt
	
a. Open it
	
b. replace "X" with X" using ctrl+h shortcut (In python double quotes has some relation with string declaration as well so did not manipulate it)
	
c. Can directly be copied to instruction memory now
P.S.
Please change the path of your input and output files i the python code
See the screenshot in the folder to see how your inputs and outputs should look like